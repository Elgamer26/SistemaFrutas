<div class="footer">
    <div class="container">
        <div class="footer-top">
            <div class="col-md-6 footer-left">
            </div>
            <div class="col-md-6 footer-right">
                <p>© 2023 Sistema de fruta. Todos los derechos reservados | Diseño por JR </p>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
</body>
</html>

<script src="<?php echo base_url(); ?>public/js/tienda.js"></script>

<script>
    var BaseUrl;
    BaseUrl = "<?php echo base_url(); ?>";
    ContarCantidadCarrito();
</script>