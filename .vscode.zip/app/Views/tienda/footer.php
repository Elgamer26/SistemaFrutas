<div class="information" style="background-color: black; color: white;">
    <div class="container">
        <div class="infor-top" style="padding: 26px;">
            <div class="col-md-4 infor-left" style="color: white">
                <h3 style="color: white">Tienda Online</h3>
                <ul>
                    <li><a>
                            <h6 style="color: white">Producto</h6>
                        </a></li>
                    <li><a>
                            <h6 style="color: white">Ofertas</h6>
                        </a></li>
                    <li><a>
                            <h6 style="color: white">Envio</h6>
                        </a></li>
                </ul>
            </div>
            <div class="col-md-4 infor-left">
                <h3 style="color: white">Información</h3>
                <ul>
                    <li><a>
                            <p style="color: white">Plantas especiales</p>
                        </a></li>
                    <li><a>
                            <p style="color: white">Nuevos productos</p>
                        </a></li>
                    <li><a>
                            <p style="color: white">Tienda Virtual</p>
                        </a></li>
                    <li><a>
                            <p style="color: white">Contáctanos</p>
                        </a></li>
                    <li><a>
                            <p style="color: white">Oferta disponibles</p>
                        </a></li>
                </ul>
            </div>

            <div class="col-md-4 infor-left">
                <h3 style="color: white">Contacto</h3>
                <h4 style="color: white">Viverio Danielito,
                    <span style="color: white">Venta de todo tipo de plantas,</span>
                    La troncal.
                </h4>
                <h5 style="color: white">0989376730</h5>
                <p><a>ViveroDamielito@hotmail.com</a></p>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>

<!-- <div class="footer">
    <div class="container">
        <div class="footer-top">
            <div class="col-md-6 footer-left">
            </div>
            <div class="col-md-6 footer-right">
                <p>© 2023 Sistema de fruta. Todos los derechos reservados | Diseño por JR </p>
            </div>
            <div class="clearfix"></div>
        </div>
        <div class="row">
            <iframe src="https://www.google.com/maps/embed?pb=!1m17!1m12!1m3!1d3985.4375089531186!2d-79.63233868524377!3d-2.68520899804372!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m2!1m1!2zMsKwNDEnMDYuOCJTIDc5wrAzNyc0OC41Ilc!5e0!3m2!1ses-419!2sec!4v1687620215159!5m2!1ses-419!2sec" width="100%" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </div>

</div> -->

<div class="footer">
    <div class="container">
        <div class="footer-top">
            <div class="col-md-6 footer-left">

            </div>
            <div class="col-md-6 footer-right">
                <p>© 2023 Vovero Danielito. Venta de todo tipos de plantas</p>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>

</body>

</html>


<script src="<?php echo base_url(); ?>public/js/tienda.js"></script>

<script>
    var BaseUrl;
    BaseUrl = "<?php echo base_url(); ?>";
    ContarCantidadCarrito();
</script>